package com.example.notetakingapp.Models

const val lilla = "#CDB4DB"
const val rosaChiaro = "#FFC8DD"
const val rosa = "#FFAFCC"
const val celeste = "#BDE0FE"
const val cartaDaZucchero = "#A2D2FF"
